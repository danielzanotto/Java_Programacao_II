
package exercicio1_classe;

public class Exercicio1_Classe {

    public static void main(String[] args) {
        pessoa pessoa1 = new pessoa(); //Você está instanciando na memoria ao criar o new
        pessoa1.nome = "João";
        pessoa1.idade = 30;
        pessoa1.saudacao();//Invoca o metodo
   }
    
}
