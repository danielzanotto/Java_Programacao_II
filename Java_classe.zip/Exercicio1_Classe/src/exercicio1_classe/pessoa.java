//
package exercicio1_classe;
public class pessoa {
    //aTRIBUTOS
    //String: Aceita todos os caracteres -> dados do tipo literal -> dado alfanumerico
    //Public - 
   public String nome;
   public int idade;
public void saudacao(){ //classe precisa ser chamada para ser executada
    //exemplo de concatenação
    System.out.println("Olá meu é "+ nome +"e tenho "+idade+" anos.");
}
}
