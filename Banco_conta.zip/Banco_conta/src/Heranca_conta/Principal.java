
package Heranca_conta;
public class Principal {

    public static void main(String[] args) {
           Conta_Corrente conta = new Conta_Corrente();
           Conta_Poupanca poupanca = new Conta_Poupanca();

           conta.Apresentar();
           conta.InserirDados();
           
           poupanca.Apresentar();
           poupanca.InserirDados();

    }
}