
package Heranca_conta;
import javax.swing.JOptionPane;
public class Conta_Corrente extends Conta{
    private double limite; //double ocupa o dobro de quantidade de memoria

public Conta_Corrente(){
    super(); //chamando o construtor da superclasse
    this.limite =0;
}   
 public void InserirDados(){
     super.setNome("Carlos Eduardo Mattos");
     super.setBanco("001 - Banco do Brasil");
     super.setAgencia("0978-8");
     super.setNroConta("22.545-9");
 }
 public void Apresentar(){//atribuição composta, concatenação (junção)
     String aux = "\nDados da Conta Corrente\n\n";
     aux += "Nome: "+super.getNome()+"\n";
     aux += "Banco: "+super.getBanco()+"\n";
     aux += "Agência: "+super.getAgencia()+"\n";
     aux += "NrConta: "+super.getNroConta()+"\n";
     aux += "Limite da Conta: " + this.limite+"\n";
     
     JOptionPane.showMessageDialog(null,aux);
 }
}
