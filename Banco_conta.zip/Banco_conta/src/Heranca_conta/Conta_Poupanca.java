/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Heranca_conta;

import javax.swing.JOptionPane;

public class Conta_Poupanca extends Conta {
 private String dataAniversario;//atributos
 
 public Conta_Poupanca(){
     super();//chamando o construtor da superclasse
     this.dataAniversario = "15 do mês";

 }
 public void InserirDados(){
     super.setNome("Marco Antonio");
     super.setBanco("23 - Bradesco");
     super.setAgencia("1363-3");
     super.setNroConta("100.987-0");
 }
 public void Apresentar(){//atribuição composta, concatenação (junção)
     String aux = "\nDados da conta Poupança\n\n";
     
     aux += "Nome: "+super.getNome()+"\n";
     aux += "Banco: "+super.getBanco()+"\n";
     aux += "Agência: "+super.getAgencia()+"\n";
     aux += "NrConta: "+super.getNroConta()+"\n";
     aux += "Data de Aniversario: " + this.dataAniversario+"\n";
     
     JOptionPane.showMessageDialog(null,aux);
 }
}
