// Daniel Zanotto
package heranca;

public class Principal {

    public static void main(String[] args) {
    //instancia os objetos.
    Vaca vaca = new Vaca();
    Peixe peixe = new Peixe();
    Cachorro dog = new Cachorro();
    
    vaca.InserirDadosVaca();
    vaca.ApresentarVaca();
    System.out.println("");//println pular linha campo ("") -> vazio
    
    peixe.InserirDadosPeixe();
    peixe.ApresentarPeixe();
    System.out.println("");//apenas print não pula linha
    
    dog.InserirDadosCachorro();
    dog.ApresentarCachorro();
    System.out.println("");
    }
    
}


//diagrama - privado, + publico.