/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca;

public class Peixe extends Animal {
 private String comprimento;//atributos
 private String velocidade;
 public void InserirDadosPeixe(){
     super.setRaca("Salmão");
     super.setPeso("45kg");
     super.setTamanhoMaximo("Média 150 cm de comprimento e 50cm de altura");
     this.comprimento = "em média de 40 metros de comprimento";
     this.velocidade = "50 m/s";
     
 }
 public void ApresentarPeixe(){
     System.out.println("Raça do peixe....: " + super.getRaca());
     System.out.println("Tamanho Maximo ....: " +super.getTamanhoMaximo());
     System.out.println("Peso do Peixe....: "+ super.getPeso());
     System.out.println("Comprimento....: "+this.comprimento);
     System.out.println("Velocidade....: "+this.velocidade);
     
 }
}
