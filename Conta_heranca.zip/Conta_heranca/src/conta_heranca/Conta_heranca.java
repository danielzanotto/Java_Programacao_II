/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conta_heranca;

public class Conta{
 private String Nome;
 private String NroConta;
 private String Agencia;
 private String Banco;
 private final double Saldo; 
// constante que será mudada ao decorrer do programa mas no final será considera constante.
 
 public void Conta(){ //possui o memso nome que a principal logo É UMA
     this.Nome = "Nome da classe";
     this.NroConta = "nro da conta";
     this.Agencia = "Agência";
     this.Banco = "Banco";
     this.Saldo = 0;
     
 }
 public void MostrarSaldo(){ //metodo quer mostrar 
     System.out.println("Saldo: R$ " + String.format("%.2f", this.Saldo));
 }
 public String getNome(){ //get -> retorna o valor
     return Nome;
 }
 public void setNome(String Nome){//set -> atualiza o valor
     this.Nome = Nome;
 }
  public String getNroConta(){ //get -> retorna o valor
     return NroConta;
 }
 public void setNroConta(String NroConta){//set -> atualiza o valor
     this.NroConta = NroConta;
 }
   public String getAgencia(){ //get -> retorna o valor
     return Agencia;
 }
 public void setAgencia(String Agencia){//set -> atualiza o valor
     this.Agencia = Agencia;
 }
  public String getBanco(){ //get -> retorna o valor
     return Banco;
 }
 public void setBanco(String Banco){//set -> atualiza o valor
     this.Banco = Banco;
 }
}
